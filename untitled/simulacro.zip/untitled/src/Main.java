import java.util.Scanner;

public class Main {


    public static void main(String[] args) {

// Crear el concesionario
        Concesionario concesionario = new Concesionario();

        Scanner scanner = new Scanner(System.in);






        boolean salir = false;
        while (!salir) {
            System.out.println("\nMenú Principal:");
            System.out.println("1. Agregar Vehículo");
            System.out.println("2. Mostrar Inventario");
            System.out.println("3. Mostrar Total del Inventario");
            System.out.println("4. Eliminar por Patente");
            System.out.println("5 .Agregar Yate y mostrar");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); //

            switch (opcion) {
                case 1:
                    // Crear vehículos y  directamente
                    Auto auto1 = new Auto("ABC123", "Toyota", "Corolla", 8.5f, 4, 25000, "300kmh", "Automático");
                    Moto moto1 = new Moto("DEF456", "Honda", "CBR500R", 4.3f, 2, 8000, 500, false);
                    // Agregar vehículos y yates al concesionario
                    concesionario.agregarvehiculo(auto1);
                    concesionario.agregarvehiculo(moto1);
                    break;
                case 2:
                    System.out.println("Listado de Inventario Inicial:");
                    System.out.println(concesionario.devolverlistado());
                    break;
                case 3:
                    System.out.println("Total del inventario: $" + concesionario.calcularTotalInventario());
                    break;
                case 4:
                    concesionario.eliminarporpatente("ABC123");
                    System.out.println("Listado de Inventario tras eliminar un vehículo:");
                    System.out.println(concesionario.calcularTotalInventario());
                    break;
                case 5:
                    // Crear  yates
                    Yate yate1=new Yate(100,true,100);
                    System.out.println("Yate:"+yate1.toString());
                case 6:
                    salir=true;
                default:
                    System.out.println("Opción no válida. Por favor, intente nuevamente.");
            }

    }
}}