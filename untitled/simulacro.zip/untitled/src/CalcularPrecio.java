public interface CalcularPrecio {

    double CalcularPrecio();

}
